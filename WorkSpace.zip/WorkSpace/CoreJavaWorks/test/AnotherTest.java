import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AnotherTest {

	@Test
	void test() {
		assertEquals(true, true);
	}

}
