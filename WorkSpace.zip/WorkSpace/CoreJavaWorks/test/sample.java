import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class sample {
	Calculate calculation = new Calculate();
    int sum = calculation.sum(2, 5);
    int testSum = 9;
 
    @Test
    public void testSum() {
        System.out.println("@Test sum(): " + sum + " = " + testSum);
        assertEquals(sum, testSum);
    }

}
