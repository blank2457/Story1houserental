package training.day2I;

public enum FuelType {
PETROL,DIESEL,CNG;
}
