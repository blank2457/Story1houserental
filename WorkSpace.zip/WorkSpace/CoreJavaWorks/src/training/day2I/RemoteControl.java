package training.day2I;

public interface RemoteControl {
void on();
void off();
}
