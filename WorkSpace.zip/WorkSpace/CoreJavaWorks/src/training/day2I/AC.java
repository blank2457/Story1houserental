package training.day2I;

public class AC extends Device implements RemoteControl{

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("Ac is on");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("AC is off");
		
	}
}
