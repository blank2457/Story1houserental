package training.day2I;

public class Honda extends Two_Wheeler{

}
