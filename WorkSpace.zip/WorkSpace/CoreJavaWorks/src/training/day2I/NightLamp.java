package training.day2I;

public class NightLamp extends Lamp implements RemoteControl{

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("Night Lamp is on");
		
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("Night Lamp is off");
	}

}
