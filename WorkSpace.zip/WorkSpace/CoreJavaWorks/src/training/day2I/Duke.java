package training.day2I;

public class Duke extends Two_Wheeler{

}
