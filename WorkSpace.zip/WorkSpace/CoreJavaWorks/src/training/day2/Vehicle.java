package training.day2;

public class Vehicle {

public void accelerate()
{
	System.out.println("Vehicle accelerated");
}
public void decelerate()
{
	System.out.println("Veicle decelerated");
}
}
