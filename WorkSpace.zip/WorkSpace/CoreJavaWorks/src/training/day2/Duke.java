package training.day2;

public class Duke extends Two_Wheeler{

}
