package training.day2;

public class Honda extends Two_Wheeler{

}
