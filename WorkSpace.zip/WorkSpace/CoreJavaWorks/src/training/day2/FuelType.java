package training.day2;

public enum FuelType {
PETROL,DIESEL,CNG;
}
