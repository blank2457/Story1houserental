package training.basics;

public class Tiger extends Animal  {

	@Override
	public void talk() {
		// TODO Auto-generated method stub
		System.out.println("Talk talks");
	}

	@Override
	public void walk() {
		// TODO Auto-generated method stub
		System.out.println("Tiger walks with two legs,two limbs ");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("grrrzzzzz");
	}

	public Tiger() {
		super();
		// TODO Auto-generated constructor stub
	}

}
