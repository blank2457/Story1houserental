package training.basics;

public class Animal {
public Animal() {
		System.out.println("Animal object");
	}
public void talk()
{
	System.out.println("Animal talks");
}
public void walk()
{
	System.out.println("Animal walks");
	
}
public void sleep()
{
	System.out.println("Animal Sleeps");
}
}
