package training.basics;

public class Largest {
public static void main(String[] args) {
	int num1=10,num2=10,num3=30;
	System.out.println(num1>num2 && num1>num3 ? "num1 is largest" : num2>num3 ? "num2 is largest" : "num3 is largest");
}
}
