package training.basics;

public class Human extends Animal {

	@Override
	public void talk() {
		// TODO Auto-generated method stub
		System.out.println("Human talks");
	}

	@Override
	public void walk() {
		// TODO Auto-generated method stub
	System.out.println("walks with two legs");
	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub
		System.out.println("zzzzzzzzzz");
	}

}
