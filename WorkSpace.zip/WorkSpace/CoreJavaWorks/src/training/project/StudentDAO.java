package training.project;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import training.project.Student;
import training.project.GetConnection;
import training.project.IStudentDAO;

public class StudentDAO implements IStudentDAO{

	@Override
	public boolean insertStudent(Student Student) {
		// TODO Auto-generated method stub
		// ? called as positional params index starts with 1
		String sql = "insert into student values(?,?,?,?,?,?,?)";
		GetConnection gc = new GetConnection();
		
		try {
			gc.ps = GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.ps.setInt(1, Student.getsId());
			gc.ps.setString(2, Student.getName());
			gc.ps.setInt(3, Student.getAge());
			gc.ps.setString(4, Student.getStandard());
			gc.ps.setString(5, Student.getDivision());
			gc.ps.setString(6, Student.getMobileno());
			gc.ps.setString(7, Student.getAddress());
			return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	 return false;
	}

	@Override
	public boolean deleteStudent(int sId) {
		// TODO Auto-generated method stub
		String sql = "delete from student where sId=?";
		GetConnection gc = new GetConnection();
        try {
			gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.ps.setInt(1, sId);
		    //System.out.println("deleted");
		    return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateStudent(int sId,String newName, int newAge, String newStandard, String newDivision, String newMobileno, String newAddress)
	{// TODO Auto-generated method stub
		String sql = "update Student set name=?,age=?,standard=?,division=?,mobileno=?,address=? where sId=?";
		GetConnection gc = new GetConnection();
        try {
			gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.ps.setString(1, newName);
			gc.ps.setInt(2, newAge);
			gc.ps.setString(3, newStandard);
			gc.ps.setString(4, newDivision);
			gc.ps.setString(5, newMobileno);
			gc.ps.setString(6, newAddress);
			gc.ps.setInt(7, sId);
		

		    //System.out.println("deleted");
		    return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Student getStudent(int sId) {
		// TODO Auto-generated method stub
		String sql = "select sId,name,age,standard,"
				+ "division,mobileno,address from student where sId=?";
		GetConnection gc = new GetConnection();
		 try {
				gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
				//gc.ps.setDouble(1, newSalary);
				gc.ps.setInt(1, sId);
			    //System.out.println("deleted");
				gc.rs = gc.ps.executeQuery();
				if(gc.rs.next()) {
					Student e = new Student();
					e.setsId(gc.rs.getInt("sId"));
					e.setName(gc.rs.getString("name"));
					e.setAge(gc.rs.getInt("age"));
					e.setStandard(gc.rs.getString("standard"));
					e.setDivision(gc.rs.getString("division"));
					e.setDivision(gc.rs.getString("mobileno"));
					e.setDivision(gc.rs.getString("address"));

					 return e;
				}
			   
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return null;
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		String sql = "select sId,name,age,standard,"
				+ "division,mobileno,address from student";
		GetConnection gc = null;
		try {
			gc=new GetConnection();
			List<Student> listStudent = new ArrayList<Student> ();
			gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.rs = gc.ps.executeQuery();
			while(gc.rs.next()) {
				Student e = new Student();
				e.setsId(gc.rs.getInt("sId"));
				e.setName(gc.rs.getString("name"));
				e.setAge(gc.rs.getInt("age"));
				e.setStandard(gc.rs.getString("standard"));
				e.setDivision(gc.rs.getString("division"));
				e.setDivision(gc.rs.getString("mobileno"));
				e.setDivision(gc.rs.getString("address"));
				listStudent.add(e);
				 
			}
			return listStudent;
		   
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				gc.ps.close();
				gc.rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}


}
