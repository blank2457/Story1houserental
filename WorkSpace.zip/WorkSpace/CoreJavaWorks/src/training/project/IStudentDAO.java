package training.project;

import java.sql.SQLException;
import java.util.List;
public interface IStudentDAO {
	public boolean insertStudent(Student Student) throws SQLException;
	public boolean deleteStudent(int sId);
	public boolean updateStudent(int sId,String newName, int newAge, String newStandard, String newDivision, String newMobileno, String newAddress);
	//select
	public Student getStudent(int sId);
	public List<Student> getAllStudents();
	
}
