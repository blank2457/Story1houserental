package training.lambda;

import java.util.*;
import java.util.stream.Collectors;

public class FilterCustomerOnPriority {
	//before java 8
	public static List<PriorityCustomer> withSalaryMoreThan(List<Customer> customers){
		List<PriorityCustomer> prioritycustomers = new ArrayList<>();
		for(Customer temp:customers) {
			if(temp.getSalary()>5000) {
				PriorityCustomer prioritycustomer = new PriorityCustomer(temp.getCustId(), temp.getCustName(), true);
				prioritycustomers.add(prioritycustomer);
			}
		}
		return prioritycustomers;
	}
	// after java 8
	public static List<PriorityCustomer> withSalaryMoreThanInJava8(List<Customer> customers){
		List<PriorityCustomer> collect = customers.stream().map(temp->{if(temp.getSalary()>5000) {
			return new PriorityCustomer(temp.getCustId(),temp.getCustName(),true);
		}
		return null;
		}).collect(Collectors.toList());
		return collect;
	}
	public static List<PriorityCustomer> withSalaryMoreThanInJava8WithFilter(List<Customer> customers){
		return customers.stream().filter(temp -> temp.getSalary()>5000)
		.map(temp->{return new PriorityCustomer(temp.getCustId(),temp.getCustName(),true);})
		.collect(Collectors.toList());
	}

public static void main(String[] args) {
	List<Customer> customers = Arrays.asList(new Customer(101,"asdsd1",7156,"Developer"),
											 new Customer(102,"asdsd2",6256,"Developer1"),
											 new Customer(103,"asdsd3",4356,"Developer2"),
											 new Customer(104,"asdsd4",4456,"Developer3")); 
	List<PriorityCustomer> prioritycustomers = withSalaryMoreThan(customers);
	prioritycustomers.forEach(System.out::println);
	System.out.println("---------------------------------------------");
	prioritycustomers = withSalaryMoreThanInJava8(customers);
	prioritycustomers.forEach(System.out::println);
	System.out.println("---------------------------------------------");

	prioritycustomers = withSalaryMoreThanInJava8WithFilter(customers);
	prioritycustomers.forEach(System.out::println);

	


}
}
