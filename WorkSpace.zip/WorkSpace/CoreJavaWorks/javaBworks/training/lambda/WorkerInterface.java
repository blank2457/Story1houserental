package training.lambda;

public interface WorkerInterface {
public void doSomeWork();
public default void imConcrete() {
	System.out.println("I'm Concrete");
}
public static void imStatic() {
	System.out.println("I'm Static");
}
}
