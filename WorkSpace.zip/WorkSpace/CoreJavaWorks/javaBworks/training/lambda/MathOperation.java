package training.lambda;

public interface MathOperation {
int operation(int x1,int x2);
}
