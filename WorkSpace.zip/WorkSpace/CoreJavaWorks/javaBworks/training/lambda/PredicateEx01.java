package training.lambda;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateEx01 {
public static void main(String[] args) {
	Predicate<Integer> positiveNumber= i -> i>=0;
	Predicate<Integer> negativeNumber= i -> i<0;
	List<Integer> list = Arrays.asList(23,-56,56,-96);
	List<Integer> filteredList = filteredList(list,positiveNumber);
	System.out.println("+ve numbers");
	filteredList.forEach(System.out::println);
	System.out.println("-ve numbers");
	List<Integer> filteredList1 = filteredList1(list,negativeNumber);
	filteredList1.forEach(System.out::println);

}

private static List<Integer> filteredList1(List<Integer> list, Predicate<Integer> negativeNumber) {
	// TODO Auto-generated method stub
	List<Integer> filteredList = new ArrayList<>();
	for(Integer temp:list) {
		if(negativeNumber.test(temp)) {
			filteredList.add(temp);
		}
	}
	return filteredList;
}

private static List<Integer> filteredList(List<Integer> list, Predicate<Integer> positiveNumber) {
	// TODO Auto-generated method stub
	List<Integer> filteredList = new ArrayList<>();
	for(Integer temp:list) {
		if(positiveNumber.test(temp)) {
			filteredList.add(temp);
		}
	}
	return filteredList;
}
}
