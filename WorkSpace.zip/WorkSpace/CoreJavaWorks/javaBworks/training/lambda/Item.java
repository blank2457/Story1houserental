package training.lambda;

import java.math.BigDecimal;

public class Item {
private String name;
private int quantity;
private BigDecimal cost;
public Item(String name, int quantity, BigDecimal cost) {
	super();
	this.name = name;
	this.quantity = quantity;
	this.cost = cost;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public BigDecimal getCost() {
	return cost;
}
public void setCost(BigDecimal cost) {
	this.cost = cost;
}
@Override
public String toString() {
	return "Item [name=" + name + ", quantity=" + quantity + ", cost=" + cost + "]";
}
}