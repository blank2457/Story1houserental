package training.lambda;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class ItemCollector {
public static void main(String[] args) {
	List<Item> items =Arrays.asList(new Item("apple",10,new BigDecimal(77.88)),
			new Item("banana",210,new BigDecimal(977.88)),
			new Item("papaya",510,new BigDecimal(1077.88)),
			new Item("papaya",100,new BigDecimal(677.88)));
	Map<String,Long> counts = items.stream()
			.collect(Collectors.groupingBy(Item::getName,Collectors.counting()));
	System.out.println(counts);
	Map<String, Integer> collect = items.stream().collect(Collectors.groupingBy(Item::getName,Collectors.summingInt(Item::getQuantity)));
	System.out.println(collect);
	Map<String, Double> collect2 = items.stream().collect(Collectors.groupingBy(Item::getName,Collectors.averagingDouble(Item::getQuantity)));
	System.out.println(collect2);
}
}
