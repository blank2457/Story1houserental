package training.lambda;

public class WorkerInterfaceTest {
Runner1 runner = new Runner1();
/*runner.execute(new WorkerInterface() {
     @Override
	public void doSomeWork() {
		System.out.println("invoked using anonymous class");
	}
});*/
}
