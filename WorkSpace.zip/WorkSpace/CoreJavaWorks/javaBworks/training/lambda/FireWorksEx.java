package training.lambda;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FireWorksEx {
	
public static void main() throws FileNotFoundException, IOException {
	// TODO Auto-generated method stub
//oldway();
	try(BufferedReader br =new BufferedReader(new FileReader("Emp.txt"))
			){
		br.lines().forEach(System.out::println);
	}
	try(Stream st = Files.lines(Paths.get("Emp.txt"))){
		
	}
}

private static void oldway() {
	try {
		BufferedReader br = new BufferedReader(new FileReader("Emp.txt"));
		String line = null;
		while((line=br.readLine())!=null) {
			System.out.println(line);
		}
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}catch(IOException e) {
		e.printStackTrace();
	
	}finally {
		
	}
}
}
