package training.lambda;

public class Runner1 implements WorkerInterface{
	public void execute(WorkerInterface worker) {
		System.out.println();
	}

	@Override
	public void doSomeWork() {
		// TODO Auto-generated method stub
		
	}
}
