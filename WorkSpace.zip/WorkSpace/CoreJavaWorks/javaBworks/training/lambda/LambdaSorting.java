package training.lambda;

import java.util.*;

public class LambdaSorting {
public static void main(String[] args) {
	List<Person> persons = Arrays.asList(new Person(101,"awd"),
			new Person(102,"awda"),
			new Person(103,"awds"),
			new Person(104,"abqd"));
	Collections.sort(persons,new Comparator<Person>() {

		@Override
		public int compare(Person o1, Person o2) {
			// TODO Auto-generated method stub
			return o1.getpId()-o2.getpId();
			//return 0;
		}
		
	});
	persons.forEach(System.out::println);
	persons.sort((o1,o2)->o1.getpId()-o2.getpId());
	System.out.println("----------------");
	persons.forEach(System.out::println);
	System.out.println("----------------");
    persons.sort((o1,o2)->o1.getpName().compareTo(o2.getpName()));
    persons.forEach(System.out::println);
	System.out.println("----------------");
    Comparator<Person> perAscName =(o1,o2)-> o1.getpName().compareTo(o2.getpName());
    persons.sort(perAscName.reversed());
    persons.forEach(System.out::println);

}
}
