package training.lambda;

import java.util.*;
import java.util.function.Consumer;

public class LambdaLooping {
public static void main(String[] args) {
	List<Integer> numbers = Arrays.asList(10,20,30,40,50);
	for(Integer temp:numbers) {
		System.out.println(temp);
	}
	System.out.println("---------------------------------");
	numbers.forEach(new Consumer<Integer>() {

		@Override
		public void accept(Integer t) {
			// TODO Auto-generated method stub
			System.out.println(t);
			
		}
		
	});
	System.out.println("------------------------------");
	numbers.forEach(t->System.out.println("lambda" +t));
	System.out.println("------------------------------");

	// method references
	numbers.forEach(System.out::println);
}
}
