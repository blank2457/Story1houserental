

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class MyBusiness {
public static void main(String[] args) {
	List<Device> listDevice = Arrays.asList(new Device(101,"earphones",2500.00,"electronics"),
			new Device(102,"earphones1",7500.00,"music1"),
			new Device(103,"earphones2",1500.00,"music2"),
			new Device(104,"earphones3",6500.00,"music3"));
	Predicate<Double> p1 = i -> i>5000;
	List<Device> filteredList1 = filter1(listDevice,p1);
	filteredList1.forEach(System.out::println);
	Predicate<Device> p2 = (temp -> temp.getCategory().equals("electronics"));
	List<Device> filteredList2 = filter2(listDevice,p2);
	filteredList2.forEach(System.out::println);
	Predicate<Device> p3 = i -> i.getPrice()>5000 && i.getCategory().equals("electronics");
	List<Device> filteredList3 = filter2(listDevice,p3);
	filteredList3.forEach(System.out::println);

	
}

private static List<Device> filter2(List<Device> listDevice, Predicate<Device> p2) {
	List<Device> filteredList1 = new ArrayList<>();
	for(Device temp:listDevice) {
		if(p2.test(temp)) {
			
			filteredList1.add(temp);
		}
	}
	return filteredList1;
}

private static List<Device> filter1(List<Device> listDevice, Predicate<Double> p1) {
	// TODO Auto-generated method stub
	List<Device> filteredList2 = new ArrayList<>();
	for(Device temp:listDevice) {
		if(p1.test(temp.getPrice())) {
			
			filteredList2.add(temp);
		}
	}
	return filteredList2;
}
}

