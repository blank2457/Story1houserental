package training.jdbc.client;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import training.jdbc.beans.Employee;
import training.jdbc.dao.EmployeeDAO;
import training.jdbc.standards.IEmployeeDAO;

public class App {
public static void main(String[] args) throws SQLException {
	//Employee employee = new Employee();
	Employee employee = new Employee(1001,"ada","sdsd@gmail.com","1980-03-08",101,40000);
	IEmployeeDAO dao = new EmployeeDAO();
	//System.out.println(dao.insertEmployee(employee)?"Inserted":"NotInserted");
	IEmployeeDAO dao1 = new EmployeeDAO();

	dao1.deleteEmployee(102);
	dao1.updateEmployee(1001, 50900.00);
	Employee e =new Employee();
	e=dao1.getEmployee(1001);
	System.out.println(e);
	List<Employee> list = new ArrayList<Employee>();
	list=dao1.getAllEmployees();
	System.out.println(list);
}
}
