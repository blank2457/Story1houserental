package training.jdbc.beans;

public class Employee {
private int empId;
private String empname;
private String empEmail;
private String empDob;
private int departmentId;
private double empSalary;
public Employee() {
	
}
public Employee(int empId, String empname, String empEmail, String empDob, int departmentId, double empSalary) {
	super();
	this.empId = empId;
	this.empname = empname;
	this.empEmail = empEmail;
	this.empDob = empDob;
	this.departmentId = departmentId;
	this.empSalary = empSalary;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getEmpEmail() {
	return empEmail;
}
public void setEmpEmail(String empEmail) {
	this.empEmail = empEmail;
}
public String getEmpDob() {
	return empDob;
}
public void setEmpDob(String empDob) {
	this.empDob = empDob;
}
public int getDepartmentId() {
	return departmentId;
}
public void setDepartmentId(int departmentId) {
	this.departmentId = departmentId;
}
public double getEmpSalary() {
	return empSalary;
}
public void setEmpSalary(double empSalary) {
	this.empSalary = empSalary;
}
@Override
public String toString() {
	return "Employee [empId=" + empId + ", empname=" + empname + ", empEmail=" + empEmail + ", empDob=" + empDob
			+ ", departmentId=" + departmentId + ", empSalary=" + empSalary + "]";
}

}
