package training.project;

import java.sql.Time;
import java.util.Date;

public class Transactions {
private int sId;
double amount;
Date d;
Time t;
private String mode_of_payment;
}
