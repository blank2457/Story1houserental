package training.jdbc.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import training.jdbc.beans.Employee;
import training.jdbc.connection.GetConnection;
import training.jdbc.standards.IEmployeeDAO;

public class EmployeeDAO implements IEmployeeDAO{

	@Override
	public boolean insertEmployee(Employee employee) {
		// TODO Auto-generated method stub
		// ? called as positional params index starts with 1
		String sql = "insert into employee values(?,?,?,?,?,?)";
		GetConnection gc = new GetConnection();
		
		try {
			gc.ps = GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.ps.setInt(1, employee.getEmpId());
			gc.ps.setString(2, employee.getEmpname());
			gc.ps.setString(3, employee.getEmpEmail());
			gc.ps.setString(4, employee.getEmpDob());
			gc.ps.setInt(5, employee.getDepartmentId());
			gc.ps.setDouble(6, employee.getEmpSalary());
			return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	 return false;
	}

	@Override
	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		String sql = "delete from employee where emp_id=?";
		GetConnection gc = new GetConnection();
        try {
			gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.ps.setInt(1, empId);
		    //System.out.println("deleted");
		    return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean updateEmployee(int empId, Double newSalary) {
		// TODO Auto-generated method stub
		String sql = "update employee set salary=? where emp_id=?";
		GetConnection gc = new GetConnection();
        try {
			gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.ps.setDouble(1, newSalary);
			gc.ps.setInt(2, empId);
		    //System.out.println("deleted");
		    return gc.ps.executeUpdate()>0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public Employee getEmployee(int empId) {
		// TODO Auto-generated method stub
		String sql = "select emp_id,emp_name,emp_email,emp_dob,"
				+ "department_id,salary from employee where emp_id=?";
		GetConnection gc = new GetConnection();
		 try {
				gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
				//gc.ps.setDouble(1, newSalary);
				gc.ps.setInt(1, empId);
			    //System.out.println("deleted");
				gc.rs = gc.ps.executeQuery();
				if(gc.rs.next()) {
					Employee e = new Employee();
					e.setEmpId(gc.rs.getInt("emp_id"));
					e.setEmpname(gc.rs.getString("emp_name"));
					e.setEmpDob(gc.rs.getString("emp_dob"));
					e.setDepartmentId(gc.rs.getInt("department_id"));
					e.setEmpSalary(gc.rs.getDouble("salary"));
					 return e;
				}
			   
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return null;
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		String sql = "select emp_id,emp_name,emp_email,emp_dob,"
				+ "department_id,salary from employee";
		GetConnection gc = null;
		try {
			gc=new GetConnection();
			List<Employee> listEmployee = new ArrayList<Employee> ();
			gc.ps=GetConnection.getMysqlConnection().prepareStatement(sql);
			gc.rs = gc.ps.executeQuery();
			while(gc.rs.next()) {
				Employee e = new Employee();
				e.setEmpId(gc.rs.getInt("emp_id"));
				e.setEmpname(gc.rs.getString("emp_name"));
				e.setEmpDob(gc.rs.getString("emp_dob"));
				e.setDepartmentId(gc.rs.getInt("department_id"));
				e.setEmpSalary(gc.rs.getDouble("salary"));
				listEmployee.add(e);
				 
			}
			return listEmployee;
		   
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
//		} finally {
//			try {
//				gc.ps.close();
//				gc.rs.close();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		}
		return null;
	}

}
