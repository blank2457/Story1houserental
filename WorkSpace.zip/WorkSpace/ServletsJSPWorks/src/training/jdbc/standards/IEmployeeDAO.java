package training.jdbc.standards;

import java.sql.SQLException;
import java.util.List;

import training.jdbc.beans.Employee;

public interface IEmployeeDAO {
// CRUD - Create,Read,Update,Delete
	public boolean insertEmployee(Employee employee) throws SQLException;
	public boolean deleteEmployee(int empId);
	public boolean updateEmployee(int empId,Double name);
	//select
	public Employee getEmployee(int empId);
	public List<Employee> getAllEmployees();
	
	
}
