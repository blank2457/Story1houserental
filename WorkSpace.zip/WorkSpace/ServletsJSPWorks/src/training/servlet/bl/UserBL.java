package training.servlet.bl;

import training.servlet.beans.LoginBean;

public class UserBL {
public static boolean validateUser(LoginBean lb) {
	return (lb.getUserName().equals("india")) && (lb.getPassword().equals("sapient"));
}
}
