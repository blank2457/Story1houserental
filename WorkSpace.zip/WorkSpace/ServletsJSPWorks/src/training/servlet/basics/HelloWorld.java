package training.servlet.basics;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class HelloWorld extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public HelloWorld() {
        super();
        System.out.println("hello world in constructor");
    
    }
    public void init() {
    	System.out.println("I'm init");
    }
    public void destroy() {
    	System.out.println("Iam destroy");
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		
		out.print("<html>");
		out.print("<head><title>Hello World in Servlet</title></head>");
		out.print("<body><h1>Welcome to servlets</h1?</body>");
		out.print("</html>");

		
	}

}
