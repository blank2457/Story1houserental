package training.servlet.basics;

import java.util.ArrayList;
import java.util.List;

import training.jdbc.dao.EmployeeDAO;
import training.jdbc.standards.IEmployeeDAO;
import training.jdbc.beans.Employee;

public class BusinessLogic {

public static List<Employee> getData() {

	IEmployeeDAO dao1 = new EmployeeDAO();
	List<Employee> list = new ArrayList<Employee>();
	list=dao1.getAllEmployees();
	System.out.println("Hi");
	System.out.println(list);
	return list;
}
}
