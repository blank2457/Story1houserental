package training.service;
import java.util.List;

import training.jdbc.beans.*;
public class EmployeeDAO {
public List<Employee> getAllEmployees(){
	return new training.jdbc.dao.EmployeeDAO().getAllEmployees();
}
}
