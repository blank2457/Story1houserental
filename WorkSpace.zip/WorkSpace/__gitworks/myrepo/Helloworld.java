class Helloworld{

public static void main(String[] args)
{
 System.out.println("hello");
}
public static void hi()
{
	
}

}
