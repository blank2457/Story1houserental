package training.day2;


class Company{
	
	final int x = 33; 
	public  void sezRules() {}
	
	public void hi() {}
}

class Sapient extends Company{

	@Override
	public void sezRules() {
		// TODO Auto-generated method stub
		super.sezRules();
	}
	
	public void hi() {}
}



public class FinalEx {

}
