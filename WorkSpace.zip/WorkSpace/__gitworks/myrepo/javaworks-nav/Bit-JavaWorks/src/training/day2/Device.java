package training.day2;

public class Device {
	private int price;

	protected int getPrice() {
		return price;
	}

	protected void setPrice(int price) {
		this.price = price;
	} 
	
	
}
