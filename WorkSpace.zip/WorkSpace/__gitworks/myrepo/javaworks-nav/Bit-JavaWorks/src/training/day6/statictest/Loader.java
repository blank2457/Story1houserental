package training.day6.statictest;

public class Loader {
	
	static {
		System.out.println("hey i'm your loader.. ");
	}
}
