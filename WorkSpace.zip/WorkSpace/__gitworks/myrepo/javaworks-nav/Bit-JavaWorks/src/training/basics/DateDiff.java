package training.basics;

/**
 * 
 * @author Naveen
 * @since July 2019
 * @see Program to find the difference of Dates 1-1-2019 - 15-07-2019 -> How
 *      many days ?
 */
public class DateDiff {
	/**
	 * 
	 * @param args
	 * @see this method is the entry point
	 */
	public static void main(String[] args) {
// single line document 
		/*
		 * this is multi line document
		 */
	}
}
