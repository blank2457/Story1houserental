package training.day2;

public interface RemoteControl {
	void on(); 
	void off(); 
}
