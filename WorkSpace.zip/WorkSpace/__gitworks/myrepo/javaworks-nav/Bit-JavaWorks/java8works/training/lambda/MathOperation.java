package training.lambda;

@FunctionalInterface
public interface MathOperation {
	int operation(int num1, int num2); 
}
